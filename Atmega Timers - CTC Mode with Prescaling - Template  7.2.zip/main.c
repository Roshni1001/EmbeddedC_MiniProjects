// Arduino clock frequency is 16 MHz

#include <avr/io.h>
#include <avr/interrupt.h>

unsigned int n_compare_matchs = 0;

ISR(TIMER2_COMPA_vect)
{
    // TASK: Use n_compare_matchs to toggle D12 on each timer interrupt 
    PORTB ^= _BV(PB4);
    n_compare_matchs++;
    if( n_compare_matchs >=125) {
      n_compare_matchs = 0;
          PORTB ^= _BV(PB5);

    }
    // and Toggle D13 at 1 sec interval.
}

int main()
{

    // TASK: set the prescaler for Timer2 to 1024
    TCCR2B = _BV(CS22) | _BV(CS21) | _BV(CS20) ;
    // TASK: set Wave Generation mode to CTC(clear Timer on Compare match)
       TCCR2A =  _BV(WGM21);
    // TASK: Set upper limit for CTC with OCR2A (remember: ticks start form 0)
     OCR2A = 124;
    // TASK: Enable Timer2 interrupt on compare match
      TIMSK2 = _BV(OCIE2A);
    // TASK: Set pin modes for D13 and D12
       DDRB= _BV(DD5)|_BV(DD4);

    // TASK: Enable Interrupts
    sei();
    while (1);
}
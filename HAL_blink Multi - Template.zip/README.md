## Blinking 3 LEDs simultaneously using HAL

## Objective 

Configuring the IO ports in CubeMX for three leds and blinking them simultaneously 
at a fixed interval(1 second).

## Steps
1. Open the CubeMX and create a new project.
2. Select the MCU STM32C036C6Tx from the MCU selector.
3. Find the pins corresponding to the pins D13,D12 and D10 configure them in output mode.
Refer: https://www.st.com/resource/en/user_manual/um2953-stm32-nucleo64-board-mb1717-stmicroelectronics.pdf
4. Generate code and upload the main.c and main.h to wokwi.
5. Write the toggling functions in the main.c and run the simulation.

## Pin configuration

1. LED 1,2,3 - D13,D12 and D11
